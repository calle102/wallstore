class RenameTransactionToCart < ActiveRecord::Migration[5.0]
  def change
    rename_table :transactions, :carts
  end
end
