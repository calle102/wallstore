class CreateItems < ActiveRecord::Migration[5.0]
  def change
    create_table :items do |t|
      t.string :ItemName
      t.integer :ItemID
      t.decimal :Price
      t.integer :Quantity
      t.text :Description

      t.timestamps
    end
  end
end
